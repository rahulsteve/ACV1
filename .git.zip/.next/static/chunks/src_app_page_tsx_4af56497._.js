(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_0c99bae4._.js",
  "static/chunks/node_modules_a791b1ea._.js"
],
    source: "dynamic"
});
